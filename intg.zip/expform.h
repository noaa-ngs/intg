#ifndef EXPFORM_H
#define EXPFORM_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: expform.h 108231 2019-02-28 14:20:15Z bruce.tran $	20$Date: 2009/05/15 15:13:22 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
void expform( int imodel );

#endif //~EXPFORM_H

