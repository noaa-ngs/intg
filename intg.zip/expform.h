#ifndef EXPFORM_H
#define EXPFORM_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: expform.h 43795 2010-07-12 16:43:17Z bruce.tran $	20$Date: 2009/05/15 15:13:22 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
void expform( void );

#endif //~EXPFORM_H

