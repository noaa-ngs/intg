#ifndef INTRO_H
#define INTRO_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: intro.h 43799 2010-07-12 16:43:32Z bruce.tran $	20$Date: 2009/05/15 15:18:51 $ NGS"

// ----- standard library --------------------------------------------
#include <stdio.h>

// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
void intro(const char* PGMVER, const char* PGMDAT);

#endif //~INTRO_H

