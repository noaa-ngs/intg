#ifndef FF2_H
#define FF2_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: ff2.h 43797 2010-07-12 16:43:24Z bruce.tran $	20$Date: 2009/05/15 15:13:59 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
int ff2(char* card, double* lat_dd, double* lon_dd, char* text);

#endif //~FF2_H

