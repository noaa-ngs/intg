#ifndef BB80LL_H
#define BB80LL_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: bb80ll.h 43794 2010-07-12 16:43:13Z bruce.tran $	20$Date: 2009/05/15 15:10:19 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
int bb80ll(char* card, double* lat, double* lon);

#endif //~BB80LL_H

