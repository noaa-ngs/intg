#ifndef FLIP_ENDIAN_D_H
#define FLIP_ENDIAN_D_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: flip_endian_d.h 35291 2010-06-11 13:16:31Z Srinivas.Reddy $	20$Date: 2009/05/15 13:59:51 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
double flip_endian_d( double dd );

#endif //~FLIP_ENDIAN_D_H

