#ifndef FF1_H
#define FF1_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: ff1.h 43796 2010-07-12 16:43:21Z bruce.tran $	20$Date: 2009/05/15 15:13:33 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
int ff1(char* card, double* lat_dd, double* lon_dd, char* text);

#endif //~FF1_H

